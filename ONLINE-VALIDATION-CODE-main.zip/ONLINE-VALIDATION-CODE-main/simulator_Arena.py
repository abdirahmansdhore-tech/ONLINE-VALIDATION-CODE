# -*- coding: utf-8 -*-
"""
Created on Wed Nov 17 15:38:29 2021

@author: franc
"""

def simulator_Arena(t_horizon):
    